import hashlib
from http.client import HTTPException

from sqlalchemy.orm import Session
from app import schemes, models

def create_user(db: Session, user: schemes.UserCreate) -> models.User:
    hashed_password = hashlib.md5(user.password.encode())
    db_user = models.User(email=user.email, first_name=user.first_name, second_name=user.second_name, password=hashed_password.hexdigest())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user(db: Session, user_id: int) -> models.User:
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_email(db: Session, email: str) -> models.User:
    return db.query(models.User).filter(models.User.email == email).first()

def update_user(db: Session, user_id: int, user_update: schemes.User) -> models.User:
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        for key, value in user_update.dict().items():
            setattr(db_user, key, value)
        db.commit()
        db.refresh(db_user)
        return db_user
    else:
        raise HTTPException(status_code=404, detail="User not found")

def delete_user(db: Session, user_id: int) -> models.User:
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        db.delete(db_user)
        db.commit()
        return db_user
    else:
        raise HTTPException(status_code=404, detail="User not found")

def create_user_record(db: Session, item: schemes.RecordCreate, user_id: int) -> models.Record:
    db_record = models.Record(**item.dict(), user_id=user_id)
    db.add(db_record)
    db.commit()
    db.refresh(db_record)
    return db_record

def get_record(db: Session, record_id: int) -> models.Record:
    return db.query(models.Record).filter(models.Record.id == record_id).first()

def update_record(db: Session, record_id: int, record_update: schemes.Record) -> models.Record:
    db_record = db.query(models.Record).filter(models.Record.id == record_id).first()
    if db_record:
        for key, value in record_update.dict().items():
            setattr(db_record, key, value)
        db.commit()
        db.refresh(db_record)
        return db_record
    else:
        raise HTTPException(status_code=404, detail="Record not found")

def delete_record(db: Session, record_id: int) -> models.Record:
    db_record = db.query(models.Record).filter(models.Record.id == record_id).first()
    if db_record:
        db.delete(db_record)
        db.commit()
        return db_record
    else:
        raise HTTPException(status_code=404, detail="Record not found")
